import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs'
import { map } from 'rxjs/operators'
@Injectable({
  providedIn: 'root'
})
export class ApiserviceService {
  baseUrl: string = 'http://localhost:61936';
  constructor(private _http: HttpClient) { }
  authenticate(model: any): Observable<any> {
    return this._http.post(this.baseUrl+'/api/user/authenticate', model).pipe(
      map((data: any) => {
        return data;
      })
    )
  }
  useractivation(activationcode: any): Observable<any> {
    return this._http.post(this.baseUrl+'/api/user/useractivation', activationcode).pipe(
      map((data: any) => {
        return data;
      })
    )
  }
  register(model: any): Observable<any> {
    return this._http.post(this.baseUrl+'/api/user/register', model).pipe(
      map((data: any) => {
        return data;
      })
    )
  }
}
