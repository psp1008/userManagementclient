import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormBuilder, FormControl, ValidationErrors, ValidatorFn } from '@angular/forms';
import { ApiserviceService } from '../../Services/apiservice.service'
import { User } from '../../models/user';
import { ActivatedRoute } from '@angular/router';
@Component({

  selector: 'app-mailConfirmation',
  templateUrl: 'mailConfirmation.component.html',
  styleUrls:['mailConfirmation.component.css'],
  providers: [ApiserviceService]
})
export class MainConfirmationComponent {
  
  constructor(private router: Router,
    private _apiservice: ApiserviceService,
    private route: ActivatedRoute
  ) {

  }
  //usermodel:any;
  activationCode:string;
  msg:Boolean=true;
  confirmationMessage:string;
  ngOnInit() {
      let para=this.route.snapshot.queryParams["activationcode"];
      console.log(para);
      this.route.params.subscribe(params => {
 this.activationCode=params.activationcode;
  console.log(this.activationCode);
  var usermodel=new User();
  usermodel.ActivationCode=this.activationCode;
  this._apiservice.useractivation(usermodel).subscribe(res=>{
      this.msg=true;
      this.confirmationMessage="Thank you! for confirming your email";
      },
      error=>{
          this.msg=false;
this.confirmationMessage="Sorry! we didn't find your registered email";
        console.log(error);
      })
 
});
 
  
}
}
