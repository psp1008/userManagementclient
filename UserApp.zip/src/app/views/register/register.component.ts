import { Component } from '@angular/core';
import { FormGroup, Validators, FormBuilder, FormControl, ValidationErrors, ValidatorFn } from '@angular/forms';
import { ApiserviceService } from '../../Services/apiservice.service'
import { User } from '../../models/user';
import{PasswordValidator} from '../../shared/confirm-equal-validator.directive'
@Component({
  selector: 'app-dashboard',
  templateUrl: 'register.component.html',
  styleUrls:['register.component.css'],
  providers:[ApiserviceService]
})
export class RegisterComponent {
 signUpForm: FormGroup;
  msg:boolean=false;
  passwordNotMatch:boolean=false;
  message:string;
  constructor(
    private _apiservice: ApiserviceService,
    private _formBuilder: FormBuilder) { }
 ngOnInit() {
    this.signUpForm = this._formBuilder.group({
      UserName: ['', [Validators.required]],
      Email: ['', [Validators.required,Validators.email]],
      password: ['', Validators.required],
      confirm_password: ['', [Validators.required]]
    }, {validator: PasswordValidator});
  }
  // confirm new password validator
 
private passwordMatcher(formGroup: FormGroup)
{
  
  const { value: password } = formGroup.get('password');
    const { value: confirmPassword } = formGroup.get('confirm_password');
    console.log(password);
    console.log(confirmPassword);
    
   return password === confirmPassword ? null : { passwordNotMatch: true };

}
    SignUpSubmit() {
    if (this.signUpForm.valid) {
      var userObject = new User();
      userObject.UserName = this.signUpForm.controls['UserName'].value;
      userObject.Password = this.signUpForm.controls['password'].value;
      this._apiservice.register(userObject).subscribe(res=>{
        console.log(res);
         this.message="User Registered Successfully";
         this.msg=true;
      },
      
      error=>{
        this.msg=true;
        this.message=error.error.message;
        console.log(error.error.message);
      })
    }
  }
}
