import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormBuilder, FormControl, ValidationErrors, ValidatorFn } from '@angular/forms';
import { ApiserviceService } from '../../Services/apiservice.service'
import { User } from '../../models/user';
@Component({
  selector: 'app-dashboard',
  templateUrl: 'login.component.html',
  styleUrls:['login.component.css'],
  providers: [ApiserviceService]
})
export class LoginComponent {
  loginForm: FormGroup;
  msg:boolean=false;
  constructor(private router: Router,
    private _apiservice: ApiserviceService,
    private _formBuilder: FormBuilder
  ) {

  }
  ngOnInit() {
    this.loginForm = this._formBuilder.group({
      UserName: ['', [Validators.required]],
      password: ['', Validators.required]
    })
  }
  SignupRedirect() {
    this.router.navigate(['/register']);
  }
  LoginSubmit() {
    if (this.loginForm.valid) {
      var userObject = new User();
      userObject.FirstName = this.loginForm.controls['UserName'].value;
      userObject.Password = this.loginForm.controls['password'].value;
      this._apiservice.authenticate(userObject).subscribe(res=>{
        console.log(res);
      },
      
      error=>{
        this.msg=true;
        console.log(error);
      })
    }
  }
}
