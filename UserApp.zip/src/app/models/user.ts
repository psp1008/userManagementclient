export class User {
  id: number;
  FirstName:string;
  LastName:string;
  UserName: string;
  Email:string;
  ActivationCode:string;
  Password:string;
  
}